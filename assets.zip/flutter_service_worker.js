'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "assets/AssetManifest.json": "7ed6534a549d6de1d124d47831bb6a71",
"assets/assets/images/0.png": "1cccac4bddd748a972166995cec55725",
"assets/assets/images/1.png": "80472b639d04c927d4652b8c348069f8",
"assets/assets/images/2.png": "cfbe3175387d9376562e79873a7e5612",
"assets/assets/images/3.png": "9ff0d7f2b97828a154a33666e5e55813",
"assets/assets/images/4.png": "59c1ebb5671330839b6e087bd1bbe1e8",
"assets/assets/images/A.png": "046a949bdf57d6fb5bd4525a47bcd475",
"assets/assets/images/Aleksandar.jpg": "6873536731df42cef6bf7456bf1739fd",
"assets/assets/images/ANC.png": "1b2411a5ea3bfa142f16ddb41476a0db",
"assets/assets/images/apoio.png": "90286820729a5182a3100b9b87c43da5",
"assets/assets/images/assiNasce.mp4": "552d3331acc75f282d5f79cda16d5e21",
"assets/assets/images/ativi.png": "5be28cef3f8763ef9eecb07702d29cee",
"assets/assets/images/avatar_default.png": "6d7a8d509be59100ec749b9ea8ab81e7",
"assets/assets/images/bannerPic.png": "2f8b851b82a1838f2f8356605ca75830",
"assets/assets/images/bulb.png": "8a2f9f48c25b64b19a1876616c28465e",
"assets/assets/images/casperProject.png": "ba5c6eea8cb2067bece49e112814301b",
"assets/assets/images/coffee_paperclips_pencil_angled_bw_w1080.jpg": "9f499cf53bb008afe9f6bd89deba9c52",
"assets/assets/images/costAction.png": "11c45df9f2a31d8d07359d40ca3cce15",
"assets/assets/images/happykids.png": "9dbf4ba61e712e76a75018b87f567693",
"assets/assets/images/Imagem9.png": "14408677bfe93bc1a96c83275aa9ba75",
"assets/assets/images/iphone_cactus_tea_overhead_bw_w1080.jpg": "319249e756f3a470d45841baea9d1132",
"assets/assets/images/joy_note_coffee_eyeglasses_overhead_bw_w1080.jpg": "f014b7b75e442ae187976761117acc17",
"assets/assets/images/logo.png": "531019fcc96ded640ef79fa5c78952b4",
"assets/assets/images/main.png": "dc5bd859e70167c64f85ac27210adf2f",
"assets/assets/images/mugs_side_bw_w1080.jpg": "7ac1959d3b134bbcef006780161606f7",
"assets/assets/images/nonprofit.png": "f64ec11c6760e58858a391303057782b",
"assets/assets/images/ogo.png": "3987472d6b63ccfbb32c1fe12a30309b",
"assets/assets/images/olivro.jpg": "1b9aafd7675ec3d5d18d836b4b5f5d9d",
"assets/assets/images/omundo.png": "dadd977e352f5f3198feba4ca928a9dd",
"assets/assets/images/paper_flower_overhead_bw_w1080.jpg": "1bed4aefd73a600a585112a77c250a6c",
"assets/assets/images/parceiros.png": "ad7d6128110b760bd2997d12faad4f3f",
"assets/assets/images/pormaiskids.png": "8c6fdc9fa8c2528b8f0b22e4db2d8c2c",
"assets/assets/images/pormaiskidsmobile.png": "aa3ad0dd17e6d4e299f951b9ed7fbda6",
"assets/assets/images/rude.PNG": "9a901decfce506712ac655271c6864ab",
"assets/assets/images/sersolidario.png": "26447e264f8f709012224b8ff72b31f1",
"assets/assets/images/shakehands.png": "fee091979485ee3a2163d7d9a39dd534",
"assets/assets/images/soudigitall.png": "3e7db9533290fa11a50a3c1f97f86f8a",
"assets/assets/images/typewriter_overhead_bw_w1080.jpg": "39e8f60e5bb2b90a5d801dd4617e7927",
"assets/assets/images/upfamilies.png": "39b0b660da99e634154b59214c6d2367",
"assets/FontManifest.json": "5a32d4310a6f5d9a6b651e75ba0d7372",
"assets/fonts/MaterialIcons-Regular.otf": "7e7a6cccddf6d7b20012a548461d5d81",
"assets/NOTICES": "2662e5dc7ccb9297197f95ef829cfee9",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "6d342eb68f170c97609e9da345464e5e",
"assets/packages/font_awesome_flutter/lib/fonts/fa-brands-400.ttf": "d1722d5cf2c7855862f68edb85e31f88",
"assets/packages/font_awesome_flutter/lib/fonts/fa-regular-400.ttf": "613e4cc1af0eb5148b8ce409ad35446d",
"assets/packages/font_awesome_flutter/lib/fonts/fa-solid-900.ttf": "dd3c4233029270506ecc994d67785a37",
"assets/packages/loading_gifs/assets/images/circular_progress_indicator.gif": "ce0141cf86895cf948736c923fa92ade",
"assets/packages/loading_gifs/assets/images/circular_progress_indicator_small.gif": "502a31bacaa2182d511eb4866354fbab",
"assets/packages/loading_gifs/assets/images/cupertino_activity_indicator.gif": "3990e106caf3029a36788b9b58a86b41",
"assets/packages/loading_gifs/assets/images/cupertino_activity_indicator_small.gif": "05ffb16f4f31cf9941a8295740476ee1",
"assets/packages/loading_gifs/assets/images/placeholder_empty.png": "978c1bee49d7ad5fc1a4d81099b13e18",
"favicon.png": "347cc610ab451605a638882dcfe54c3d",
"icons/Icon-192.png": "b7d8d10eef2cf87b9b53539f8879c66a",
"icons/Icon-512.png": "abc9d01a0bb18d86195c6053d652f149",
"icons/Icon-maskable-192.png": "aa661a27b49c771216deb8c71f091bc6",
"icons/Icon-maskable-512.png": "a879641542d57ad0d7457ec53b492aa5",
"index.html": "b388282961ff3d03455ac0d6dd14d210",
"/": "b388282961ff3d03455ac0d6dd14d210",
"main.dart.js": "4308805896dd6979f0af7b454cd255f7",
"manifest.json": "6128c64a42298c3c9799c3f045ff7696",
"Minimal-Favicon.png": "0b142f8f8dcc0a90131fab06535a200b",
"version.json": "f9a4766602ece750e4c8727958f97a60"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "/",
"main.dart.js",
"index.html",
"assets/NOTICES",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache.
        return response || fetch(event.request).then((response) => {
          cache.put(event.request, response.clone());
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
