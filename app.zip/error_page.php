<?php
include ('./app/include/header.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Something Went Wrong</title>
    <style>
        .error-message {
            margin-top: 120px;
            text-align: center;
            font-size: 24px;
            color: #333;
        }
        .next-steps {
            margin-top: 40px;
            text-align: center;
        }
        a {
            color: #007BFF;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="error-message">
        <h1>Oops! Algo correu errado.</h1> 
        <p>Pedimos desculpa pela a inconveniência. Tente novamente mais tarde.</p>
    </div>
    <div class="next-steps">
        <p><a href="index.php">Voltar para a página principal</a></p>
    </div>
    <?php
include ('./app/include/footer.php');
?>

</body>
</html>
