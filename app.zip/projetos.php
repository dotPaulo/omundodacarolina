<?php 
    $headerPath = './app/include/header.php';
    $scrollbarPath = './app/include/scrollbar.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/CSS/projetos.css">
    <title>Projetos | omundodacarolina</title>
    <link rel="shortcut icon" type="image/png" href="assets/Imagens/favicon.ico">
</head>
<body>
<?php include $headerPath; ?>
<?php include $scrollbarPath; ?>
<main>
<div id="projetos" class="projeto-container">
        <div  class="projeto-header">
          <h1>Projetos </h1>
        </div>
        <div class="projeto-area">
        <div  onclick="location.href='eusoudigital.php'" class="projeto-box">
          <div class="projeto-imagem">
            <img src="assets/Imagens/EUSOUDIGITAL.png" alt="EUSOUDIGITAL">
          </div>
          <div class="projeto-titulo">
            <h2>Programa 'EUSOUDIGITAL'</h2>
          </div>
          <div class="projeto-antevisao">
            <span>Em família, com os amigos, perto de casa. Aprender (ou ensinar) a usar a internet é o desafio do programa EUSOUDIGITAL. Conheça-o.</span>
          </div>
        </div>
        <div onclick="location.href='casper.php'" class="projeto-box">
          <div class="projeto-imagem">
            <img src="assets/Imagens/CASPER.png" alt="CASPER">
          </div>
          <div class="projeto-titulo">
            <h2>Quem é NGI: Aleksandar Jevremovic Apresenta Casper para proteger crianças online</h2>
          </div>
          <div class="projeto-antevisao">
            <span>O Projeto Casper foi concebido para proteger as crianças de ameaças online. Estamos a tentar criar um supervisor artificial que proteja as crianças quando utilizam a Internet contra pornografia, nudez, predadores, ciberbullying, doutrinação, desafios da Internet, envolvimento em atividades criminosas, etc. O nosso projeto utiliza Inteligência artificial (IA) ao nivel da interação homem-computador, preservando a privacidade.</span>
          </div>
        </div>
        <div onclick="location.href='eurocan.php'" class="projeto-box">
          <div class="projeto-imagem">
            <img src="assets/Imagens/EuroCan.png" alt="EUROCAN">
          </div>
          <div class="projeto-titulo">
            <h2>CA19106 - Respostas Multissetoriais ao abuso e negligências </h2>
          </div>
          <div class="projeto-antevisao">
            <span>Na Europa, milhões de crianças sofrem abusos ou negligências nas mãos daqueles que devem cuidar delas. No entanto, quantas destas crianças recebem ajuda, quais os serviços que recebem pela agência que permanece em grande parte desconhecida. Além disso, os países mal-sabíamos quais os maus tratos que se tornam fatais. Trata-se de uma grande lacuna de conhecimento que se deve, provavelmente, a formas inconsistentes de pesquisar e reportar serviços de maus tratos a crianças em toda a Europa. Sem esta informação, não podemos saber como funcionam os sistemas, que esforços preventivos adicionais são necessários, se as intervenções se adequam às necessidades das vítimas ou se os grupos mais vulnerávels estão devidamente Identificados.</span>
          </div>
        </div>
      </div>
    </div>
</main>
<?php
   include './app/include/footer.php'
?>
</body>
</html>