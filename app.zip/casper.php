<?php 
    $headerPath = './app/include/header.php';
    $scrollbarPath = './app/include/scrollbar.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/CSS/posts.css">
    <title>CASPER | omundodacarolina</title>
    <link rel="shortcut icon" type="image/png" href="assets/Imagens/favicon.ico">
</head>
<body>
<?php include $headerPath; ?>
<?php include $scrollbarPath; ?>
    <main>
        <section>
            <div class="post-container">
                <div class="post-box">
                    <div class="image-container">
                        <img src="./assets/Imagens/CASPER.png" alt="casper">
                    </div>
                    <div class="content">
                        <div class="title-container">
                            <h1>Quem é NGI: Aleksandar Jevremovic Apresenta Casper para proteger crianças online</h1>
                        </div>
                        <p>O Projeto Casper foi concebido para proteger as crianças de ameaças online. Estamos a tentar
                            criar um supervisor artificial que proteja as crianças quando utilizam a Internet contra
                            pornografia, nudez, predadores, ciberbullying, doutrinação, desafios da Internet,
                            envolvimento em atividades criminosas, etc. O nosso projeto utiliza inteligência artif
                            icial (IA) ao nível da interação homem-computador, preservando a privacidade. </p> <br>
                        <p>
                            A minha mulher e eu temos três filhos relativamente pequenos (1
                            3, 11 e 8), e enfrentámos o problema de lhes ser mostrado conteúdo inadequado, sob a forma
                            de anúncios, banners e reorientações. Pessoalmente, a minha família tem o luxo de passar
                            muito tempo com os nossos filhos, supervisioná-los e protegê-los das ameaças acima
                            referidas. No entanto, estou plenamente ciente de que muitos pais não estão na mesma
                            posição, e que muitas criança
                            s são muito mais vulneráveis quando usam a Internet. Estamos a tentar resolver este
                            problema.
                        </p> <br>
                        <p>
                            A minha equipa fez uma extensa pesquisa sobre este tema
                            e tentou muitas soluções atualmente disponíveis, mas os resultados esta
                            vam longe de ser perfeitos. Falei sobre isso com os meus colegas, como seria uma
                            'solução perfeita' para isto e foi assim que obtivemos a idela de um 'supervisor movido a
                            IA'. Profissionalmente, também explorei o campo para a IA em interação homem-computador,
                            devido à minha posição no Comité Técnico de Interação Homem-Computador (TC13) na
                            IFIP/UNESCO. No entanto, precisávamos de uma abordagem mais formal, para ter mais
                            investigadores/desenvolvedores e mais compromisso - para poder materializar a ideia.
                            Tínhamos um conceito, mas a NGI ajudou-nos a prová-lo.
                        </p> <br>
                        <div class="title-container">
                            <h2>Suporte NGI</h2>
                        </div>
                        <p>
                            Os meus colegas encontraram a informação sobre a primeira chamada do NGI Trust e sugeriram
                            que deviamos escrever uma proposta. No Início, estava um pouco reservado, uma vez que não
                            tínhamos muita experiência em escrever propostas para projetos financiados pela UE, e
                            receava que o financiamento nos obrigasse a mudar o rumo da investigação. No entanto, a
                            chamada parecia muito interessante, bem como toda a iniciativa da NGI, por isso decidimos
                            tentar. Estamos muito felizes por nos termos candidatado.
                        </p> <br>
                        <p>
                            A forma mais óbvia de o NGI apoiar a nossa ideia é financiando o nosso trabalho.
                            Permitiu-nos ter os investigadores e desenvolvedores capazes de Investir mais do seu tempo
                            neste projeto. Além disso, pessoas da NGI organizaram a nossa participação em muitos grandes
                            eventos, como a Web Summit em Lisboa, ou o Internet Governance Forum em Berlim, para
                            apresentar o projeto e obter feedback relevante. Algumas ótimas opções de treino e mentoria
                            estavam disponívels através do NGI Tetra. Além disso, recebemos conselhos e informações
                            muito úteis diretamente dos caras da NGI. Provavelmente desperdiçámos algum do seu tempo com
                            algumas perguntas muito básicas, mas foram demasiado amáveis para nos dizerem isso. Por
                            último, mas não menos importante, para nós, era muito importante que as pessoas da NGI
                            reconhecessem a nossa ideia e a apoiassem - realmente impulsionou a nossa autoconfiança.
                        </p> <br>
                        <div class="title-container">
                            <h2>Projeto Casper</h2>
                        </div>
                        <p>
                            Existem muitos projetos com o mesmo objetivo - proteger as crianças que usam a Internet.
                            Além disso, alguns deles estão a usar IA. As principais características do nosso projeto são
                            que ele usa Al no nível de interação homem-computador, suporta diferentes tipos de conteúdo
                            (Imagem, vídeo, áudio, texto), suporta uma ampla e extensível gama de ameaças, e, talvez o
                            mais importante, tenta entender profundamente o que está acontecendo nas comunicações
                            Intercetadas. Além disso, estamos a explorar a possibilidade de permitir a colaboração (por
                            exemplo, na deteção de predadores), preservando ao mesmo tempo a privacidade do utilizador.
                        </p> <br>
                        <p>
                            Inicialmente, o plano era muito simples - desenvolver software para permitir a gravação de
                            ecrā/ áudio, que aplica algoritmos de IA para detetar conteúdo impróprio, e que esconde esse
                            conteúdo ou alarma os pais. No entanto, descobriu-se que as coisas são um pouco mais
                            complicadas, e a solução tem de ser mais sofisticada. Diferentes plataformas (Linux,
                            Windows, Mac, Android, IOS) utilizam diferentes arquiteturas de interface de utilizador, e
                            estamos a tentar evitar garfos. Alguns algoritmos de IA não eram bons o suficiente.
                            Precisávamos de treinos muito maiores. Esconder conteúdo sonoro inadequado é impossível, ou
                            é necessário algum atraso significativo. A capacidade de computação dos telemóveis não é
                            suficiente para uma proteção em tempo real. Então, de certa forma, os problemas que
                            enfrentámos moldaram a ideia.
                        </p> <br>
                        <p>
                            Novas ideias apareceram através de feedback, consultando pessoas da academia e da Indústria.
                            Além disso, as decisões arquitetónicas obrigaram-nos a fornecer algum espaço para o futuro e
                            potenciais ideias e utilizações. Decidimos tornar a arquitetura mals genérica e modular,
                            para evitar a dívida técnica arquitetónica.
                        </p> <br>
                        <p>
                            Estamos longe de ser especialistas em marketing, mas a ideia por trás do projeto é
                            relativamente simples e compreensível, pelo que é fácil partilhar e promover. Os meus
                            colegas Milan e Marko juntaram-se ao comité de gestão de uma ação cost 'Colaboração
                            Transnacional sobre Bullying, Migração e Integração a Nível Escolar', para que possam
                            partilhar informações e obter feedback dos investigadores em ciências socials.
                        </p> <br>
                        <p>
                            Planeamos frequentar alguns campos de treino organizados pela NGI Tetra, de forma a melhorar
                            os nossos conhecimentos em áreas como a gestão da propriedade intelectual, obtenção de
                            financiamento, etc. Somos bons em pesquisa, e valorizamos software gratuito e de código
                            aberto, mas ainda temos que aprender muito sobre negócios.
                        </p> <br>
                        <div class="title-container">
                            <h2>A comunidade NGI - e além</h2>
                        </div>
                        <p>
                            Há grande entusiasmo e energia na comunidade NGI. A minha impressão é que as pessoas da NGI
                            estão a gerar mais oportunidades do que a população-alvo pode seguir. Quase todos os dias
                            pode ver algo novo publicado através do Linkedin, do site ou de outros canais. E isso não é
                            uma coisa comum hoje em dia.
                        </p> <br>
                        <p>
                            O NGI tem uma grande combinação de profissionalismo, precisão, espontaneidade e
                            improvisação. Pode ver isto, por exemplo, na rapidez com que ultrapassaram os problemas dos
                            acontecimentos cancelados devido ao Coronavirus. Compreende que faz parte de uma
                            ideia/plano/projeto muito maior, mas tem liberdade para explorar e incluir coisas novas.
                            Acho que isso é muito importante para atrair tipos relevantes de pessoas que podem gerar
                            novas ideias, mas também concretizá-las.
                        </p> <br>
                        <p>
                            Criámos um novo quadro de Investigação neste domínio, pelo que a parte da investigação
                            continuará definitivamente a existir, bem como alguns sub-projectos. No entanto, a nossa
                            tarefa é encontrar formas de continuar o projeto global, uma vez que está a Integrar todos
                            estes componentes, preservando a direção e acelerando o desenvolvimento.
                        </p> <br>
                        <p>
                            Abrimos a caixa de Pandora, e seria muito difícil fechá-la agora. Em definitivo, pretendemos
                            continuar o nosso trabalho independentemente do fim do apolo da NGI. Não tenho a certeza
                            sobre a forma final que val tomar, mas as coisas não vão acabar, com certeza.
                        </p> <br>
                        <div class="title-container">
                            <h2>Sobre o autor</h2>
                        </div>
                        <p>
                            Aleksandar Jevremovic é professor na Universidade de Singidunum, na Sérvia, onde a sua
                            equipa criou um dos primeiros programas de estudos de licenciatura relacionados com a
                            segurança Informática no Sudeste da Europa, investigador na Escola de Engenharia
                            Eletrotécnica de Belgrado, professor convidado na Universidade de Harvard, nos EUA, e um
                            estudioso visitante da Universidade de Tecnologia de Chipre.
                        </p> <br>
                        <p>
                            O Projeto Caspar tem outros quatro membros do projeto da Sérvia (Mladen Veinovic, Milan
                            Cabarkapa, Milos Stojmenovic e Marko Krstic), e quatro da Macedónia do Norte e de Portugal
                            (Ivan Chorbev, Ivica Dimitrovski, Nuno Garcia e Nuno Pombo).
                        </p> <br>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <?php include './app/include/footer.php'; ?>
</body>

</html>