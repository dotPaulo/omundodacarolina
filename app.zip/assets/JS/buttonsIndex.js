document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('contactButton').addEventListener('click', function (event) {
        event.preventDefault();

        const footer = document.getElementById('footer');
        const footerOffset = footer.offsetTop;
        const startPosition = window.pageYOffset;
        const distance = footerOffset - startPosition;
        const duration = 3000; 
        let start = null;
        function step(timestamp) {
            if (!start) start = timestamp;
            const progress = timestamp - start;
            window.scrollTo(0, easeInOutQuad(progress, startPosition, distance, duration));
            if (progress < duration) {
                window.requestAnimationFrame(step);
            } else {
                setTimeout(function() {
                    document.getElementById('highlightText').classList.add('highlighted');
                }, 100); 
            }
        }

        window.requestAnimationFrame(step);
    });
    document.getElementById('ReadMore').addEventListener('click', function (event) {
        event.preventDefault(); 
    
        const projetos = document.getElementById('projetos');
        const footerOffset = projetos.offsetTop;
        const footerStyles = window.getComputedStyle(projetos); 
        const paddingTop = parseFloat(footerStyles.paddingTop);
        const startPosition = window.pageYOffset;
        const distance = footerOffset - startPosition - paddingTop; 
        const duration = 2000; 
    
        let start = null;
    
        function step(timestamp) {
            if (!start) start = timestamp;
            const progress = timestamp - start;
            window.scrollTo(0, easeInOutQuad(progress, startPosition, distance, duration));
            if (progress < duration) {
                window.requestAnimationFrame(step);
            }
        }
    
        window.requestAnimationFrame(step);
    });
    
});

function easeInOutQuad(t, b, c, d) {
    t /= d / 2;
    if (t < 1) return c / 2 * t * t + b;
    t--;
    return -c / 2 * (t * (t - 2) - 1) + b;
}


