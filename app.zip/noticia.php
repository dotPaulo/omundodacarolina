<?php 
    $headerPath = './app/include/header.php';
    $scrollbarPath = './app/include/scrollbar.php';
?>
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/CSS/noticia.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Notícias | omundodacarolina</title>
    <link rel="shortcut icon" type="image/png" href="assets/Imagens/favicon.ico">
</head>
<body>
<?php include $headerPath; ?>
<?php include $scrollbarPath; ?>
    <main>
    <div class="noticias-container">
        <div class="noticias-header">
          <h1>Notícias </h1>
        </div>
      <div class="noticias-area">
        <div onclick="location.href='sersolidario.php'" class="noticias-box">
          <div class="noticias-imagem">
            <img src="assets/Imagens/SERSOLIDARIO.png" alt="UPFAMILIES">
          </div>
          <div class="noticias-titulo">
            <h2>Programa 'Ser Solidário' </h2>
          </div>
          <div class="noticias-antevisao">
            <span>Nos ámbitos do apoio social e do exercício da responsabilidade social, a Universidade da Beira Interior decidiu implementar o programa 'Ser Solidário', com o objetivo de desenvolver mecanismos complementares para uma resposta mals eficaz e abrangente na concessão de apolos socials aos membros da sua comunidade académica.</span>
          </div>
        </div>
        </div>
      </div>
    </div>
    </main>
<?php
   include './app/include/footer.php'
?>
</body>
</html>