<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/CSS/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Document</title>
</head>

<body>
    <footer id="footer">
        <div class="footer">
            <div class="container">
                <div class="cabecalho-text">
                    <i id="highlightText" class="fa-regular fa-envelope"><span>geral@omundodacarolina.pt</span></i>
                    <i onclick="location.href='noticia.php'"><a class="text"> Notícias</a></i>
                    <i><a class="text" onclick="location.href='projetos.php'"> Projetos</a></i>
                    <span>2024© Todos os direitos reservados.</span>
                </div>
                <div class="footer-imagens">
                    <div class="footer-logo">
                        <img onclick="location.href='index.php'" class="logo-footer" src="assets/Imagens/logo.png"
                            alt="">
                    </div>
                    <div class="footer-confinanciado">
                        <i><img class="confinanciado-footer" src="assets/Imagens/Confinanciado.png" alt=""></i>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>