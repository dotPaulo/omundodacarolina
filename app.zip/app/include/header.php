<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/CSS/header.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Document</title>
</head>

<body>
    <header class="header">
        <a href="index.php"><img src="assets/Imagens/logo.png" class="logo" alt="omundodacarolina"></a>
        <div class="hamburger">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
        <nav class="navbar">
            <ul>
                <li>
                    <a class="noticia" href="noticia.php">Notícias</a>
                </li>
                <div class="dropdown">
                    <li>
                        <a class="projetos" href="projetos.php">Projetos<i class="fas fa-angle-down"></i> </a>
                    </li>

                    <div class="dropdown-content">
                        <a href="eusoudigital.php">Projeto 'Eu sou Digital'</a>
                        <a href="casper.php">Projeto 'Casper'</a>
                        <a href="eurocan.php">Projeto 'EuroCan'</a>
                    </div>
                </div>
                <li>
                    <a class="sobre" href="sobre.php">Sobre</a>
                </li>
            </ul>
        </nav>
        <div class="header-sociais">
            <a href="https://www.facebook.com/omundodacarolina/" target="_blank"><i
                    class="fa-brands fa-facebook fa-2xl"></i></a>
            <a href="https://www.youtube.com/channel/UC0bI4TjGgFKTBNAOBFbGSgA/videos" target="_blank"><i
                    class="fa-brands fa-youtube fa-2xl"></i></a>
        </div>
    </header>
    <script defer src="assets/JS/menu.js"></script>
</body>

</html>