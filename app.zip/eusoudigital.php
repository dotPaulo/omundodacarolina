<?php 
    $headerPath = './app/include/header.php';
    $scrollbarPath = './app/include/scrollbar.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/CSS/posts.css">
    <title>EuSouDigital | omundodacarolina</title>
    <link rel="shortcut icon" type="image/png" href="assets/Imagens/favicon.ico">
</head>
<body>
<?php include $headerPath; ?>
<?php include $scrollbarPath; ?>
    <main>
        <section>
            <div class="post-container">
                <div class="post-box">
                    <div class="image-container">
                        <img src="assets/Imagens/EUSOUDIGITAL.png" alt="EUSOUDIGITAL">
                    </div>
                    <div class="content">
                        <div class="title-container">
                            <h1>Programa 'EUSOUDIGITAL'</h1>
                        </div>
                        <p>Em família, com os amigos, perto de casa. Aprender (ou ensinar) a usar a internet é o
                            desafio do programa EUSOUDIGITAL. Conheça-o. </p> <br>
                        <p>
                            Marcar uma consulta médica, fazer uma transferência bancária, enviar um e-mail, conversar
                            com familiares e amigos, planear as férias, comprar roupa ou alimentos, aprender uma receita
                            nova, fazer exercício. Todos os dias, milhões de portugueses gerem o quotidiano através do
                            telemóvel, tablet ou computador. Mas há muitos outros que não o podem fazer. Simplesmente
                            porque não sabem como.
                        </p> <br>
                        <p>
                            Segundo dados do Governo, em 2020, a percentagem da população que nunca utilizou a internet
                            atingia os 18%. Isto é, quase um quinto dos portugueses nunca acedeu a esta rede que
                            simplifica a vida quotidiana e liga milhões de pessoas em todo o mundo. E que, como o
                            contexto pandémico veio revelar, é cada vez mais essencial.
                        </p> <br>
                        <p>
                            Reduzir este número e não deixar ninguém para trás é o objetivo do Programa EUSOUDIGITAL.
                            Uma iniciativa financiada pela Caixa Geral de Depósitos, que se associa como investidor
                            social, promovida pelo MUDA - Movimento pela Utilização Digital Ativa com apoio da Estrutura
                            de Missão Portugal Digital e cofinanciado pelo Portugal Inovação Social, POISE - Programa
                            Operacional Inclusão Social e Emprego, Portugal 2020 e pela União
                            Europeia.
                        </p>
                        <div class="title-container">
                            <h2>Como funciona o EUSOUDIGITAL</h2>
                        </div>
                        <p>
                            Um milhão de portugueses a aprender a usar a internet e torná-los mais
                            habilitados até 2023 pode parecer um número elevado, até porque a data não está assim tão
                            distante.
                            Como se atinge um objetivo tão ambicioso? Da mesma forma que o difícil se torna fácil. Ou
                            seja, unindo esforços e convocando cada um de nós para fazer a sua parte.
                        </p> <br>
                        <p>
                            O EUSOUDIGITAL assenta em tem três pilares:
                        </p> <br>
                        <p>
                            # Os mentores, ou seja, os voluntários que estão dispostos a ajudar;
                        </p> <br>
                        <p>
                            # Os centros de formação isto é, cerca de 1 500 locais em todo o país onde vai ser possível
                            aprender;
                        </p> <br>
                        <p>
                            # Os alunos (o que corresponde a um universo de cerca de um milhão de adultos) que vão
                            aprender a usar a Internet.
                        </p> <br>
                        <p>
                            A vantagem é que todo este processo se desenvolve num contexto de proximidade. Começa em
                            casa, com a família e continua no café do bairro, na agência do seu Banco, na junta de
                            freguesia ou noutro espaço perto de quem quer aprender e de quem deseja ensinar. Vejamos,
                            então, como participar neste projeto.
                        </p>
                        <div class="title-container">
                            <h2>Como ser voluntário?</h2>
                        </div>
                        <p>
                            Para muitos a experiência não é nova. Quase todos já tivemos de ensinar algum familiar a
                            lidar com questões relacionadas com a internet. Agendar a vacinação contra a Covid-19,
                            entregar a declaração de IRS ou, até, fazer compras online.
                        </p> <br>
                        <p>
                            Isto significa que ser um voluntário no EUSOUDIGITAL é apenas o prolongamento destes
                            pequenos gestos. E, para quem precisa de aprender, esse apoio pode significar uma vida mais
                            simples, mais preenchida e menos isolada.
                        </p> <br>
                        <p style="font-weight:600;">
                            O primeiro passo para ser voluntário é fazer a inscrição através do <a target="_blank"
                                href="https://eusoudigital.pt/">site do projeto.</a>
                        </p> <br>
                        <p>
                            Para que um voluntário possa tornar-se um mentor basta fazer uma formação que o prepare para
                            ensinar pessoas que nunca usaram a internet. Ou seja, por onde começar, como explicar e como
                            facilitar o processo de aprendizagem dos alunos.
                        </p> <br>
                        <p>
                            Esta formação, baseada em vídeos e webinars específicos e de fácil apreensão, é feita na
                            plataforma do programa, em casa e conforme a disponibilidade de cada um. Quando estiver
                            concluída, o voluntário recebe um Certificado de Mentor EUSOUDIGITAL. Isto significa que
                            pode começar a ensinar. E a mudar vidas. Nomeadamente daqueles que lhe são próximos.
                        </p> <br>
                        <ul>
                            <li>Como se ensina?</li> <br>
                            <li>As sessões têm a duração de duas horas. Destinam-se a adultos acima dos 45 anos, que
                                podem aprender a navegar na Internet, a pesquisar online e a criar a sua identidade
                                digital.</li>
                        </ul>
                        <div class="title-container">
                            <h2>Como aprender?</h2>
                        </div>
                        <p>
                            Os alunos são a razão de ser do EUSOUDIGITAL e, mesmo não podendo ensinar ou receber
                            formação num centro, todos podemos levar alguém até ao projeto. Avós, país, familiares que
                            vivem longe dos centros urbanos, vizinhos... Todos conhecemos alguém que gostaria de
                            aprender a usar a Internet para comunicar, tratar de questões do dia-a-dia ou, simplesmente,
                            para ter acesso a mais informação e entretenimento.
                        </p> <br>
                        <p>
                            Para que essa pessoa possa, também, incluir-se na gigantesca comunidade de utilizadores da
                            internet, basta que seja registada pelo familiar ou amigo que esteja inscrito como mentor
                            EUSOUDIGITAL.
                        </p> <br>
                        <p>
                            Para que essa pessoa possa, também, incluir-se na gigantesca comunidade de utilizadores da
                            internet, basta que seja registada pelo familiar ou amigo que esteja inscrito como mentor
                            EUSOUDIGITAL. Depois, e mesmo sem sair de casa, pode começar a aprender, através da
                            plataforma, contando sempre com a ajuda do seu mentor.
                        </p> <br>
                        <p>
                            O desafio está lançado mas há que levá-lo a bom termo. Para isso, o EUSOUDIGITAL conta com a
                            participação de todos e o primeiro passo está sempre à distância de um clique. Inscreva-se
                            como mentor e ajude alguém próximo a poder afirmar EUSOUDIGITAL.
                        </p>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <?php include './app/include/footer.php'; ?>
</body>

</html>