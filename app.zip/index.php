<?php 
    $headerPath = './app/include/header.php';
    $scrollbarPath = './app/include/scrollbar.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="./assets/CSS/index.css">
    <title>omundodacarolina</title>
    <link rel="shortcut icon" type="image/png" href="assets/Imagens/favicon.ico">
    </head>
<body>
<?php include $headerPath; ?>
<?php include $scrollbarPath; ?>
<main>
   <!------------------------------- hero ------------------------------------>
  <section>
    <div class="hero-slider">
      <div class="landing-hero">
        <div class="hero-text">
          <span>A Transformar vidas e levar <br>esperança a crianças e jovens.</span>
          <div class="hero-btn">
            <button id="ReadMore" class="hero-btn1">Ler mais</button>
          </div>
        </div>          
      </div>
      <div class="hero-list">
        <div class="hero-item">
          <img src="assets/Imagens/ftindex3.jpg" alt="">
        </div>
        <div class="hero-item">
          <img src="assets/Imagens/ftindex2.jpg" alt="">
        </div>
        <div class="hero-item">
          <img src="assets/Imagens/ftindex1.jpg" alt="">
        </div>
      </div>
      <div class="hero-buttons">
        <button id="prev"></button>
        <button id="next"></button>
      </div>
      <ul class="hero-dots">
        <li class="active"></li>
        <li></li>
        <li></li>
      </ul>
    </div>
  </section>

   <!------------------------------- Hyperlink ------------------------------------>

  <section>
    <div class="hyperlink-container">
      <div class="hyperlink">
        <div class="hyperlink-box">
          <div class="hyperlink-icone">
            <i id="icon" class="fa-solid fa-list-check fa-2xl"></i>
          </div>
          <div class="hyperlink-text">
            <div class="hyperlink-h3">
              <h3>Projetos</h3>
            </div>
            <div class="hyperlink-span">
              <span>Descubra os nossos projetos</span>
            </div>
            <button onclick="location.href='projetos.php'" class="hyperlink-btn">Saiba mais</button>
          </div>
        </div>
        <div class="hyperlink-box">
          <div class="hyperlink-icone">
            <i id="icon" class="fa-solid fa-circle-info fa-2xl"></i>
          </div>
          <div class="hyperlink-text">
            <div class="hyperlink-h3">
              <h3>Sobre</h3>
            </div>
            <div class="hyperlink-span">
              <span>Saiba mais sobre a associação</span>
            </div>
            <button onclick="location.href='sobre.php'" class="hyperlink-btn">Saiba mais</button>
          </div>
        </div>
        <div class="hyperlink-box">
          <div class="hyperlink-icone">
            <i class="fa-solid fa-comment fa-flip-horizontal fa-2xl"></i>
          </div>
          <div class="hyperlink-text">
            <div class="hyperlink-h3">
              <h3>Contactos</h3>
            </div>
            <div class="hyperlink-span">
              <span>Entre em contacto para mais informações</span>
            </div>
            <button class="hyperlink-btn" id="contactButton">Contactos</button>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!------------------------------- Projetos ------------------------------------>

  <section>
    <div id="projetos" class="projeto-container">
        <div  class="projeto-header">
          <h1>Últimos Projetos </h1>
          <button onclick="location.href='projetos.php'" >Ver todos</button>
        </div>
      <div class="projeto-area">
        <div  onclick="location.href='eusoudigital.php'" class="projeto-box">
          <div class="projeto-imagem">
            <img src="assets/Imagens/EUSOUDIGITAL.png" alt="EUSOUDIGITAL">
          </div>
          <div class="projeto-titulo">
            <h2>Programa 'EUSOUDIGITAL'</h2>
          </div>
          <div class="projeto-antevisao">
            <span>Em família, com os amigos, perto de casa. Aprender (ou ensinar) a usar a internet é o desafio do programa EUSOUDIGITAL. Conheça-o.</span>
          </div>
        </div>
        <div onclick="location.href='casper.php'" class="projeto-box">
          <div class="projeto-imagem">
            <img src="assets/Imagens/CASPER.png" alt="CASPER">
          </div>
          <div class="projeto-titulo">
            <h2>Quem é NGI: Aleksandar Jevremovic Apresenta Casper para proteger crianças online</h2>
          </div>
          <div class="projeto-antevisao">
            <span>O Projeto Casper foi concebido para proteger as crianças de ameaças online. Estamos a tentar criar um supervisor artificial que proteja as crianças quando utilizam a Internet contra pornografia, nudez, predadores, ciberbullying, doutrinação, desafios da Internet, envolvimento em atividades criminosas, etc. O nosso projeto utiliza Inteligência artificial (IA) ao nivel da interação homem-computador, preservando a privacidade.</span>
          </div>
        </div>
        <div onclick="location.href='eurocan.php'" class="projeto-box">
          <div class="projeto-imagem">
            <img src="assets/Imagens/EuroCan.png" alt="EUROCAN">
          </div>
          <div class="projeto-titulo">
            <h2>CA19106 - Respostas Multissetoriais ao abuso e negligências </h2>
          </div>
          <div class="projeto-antevisao">
            <span>Na Europa, milhões de crianças sofrem abusos ou negligências nas mãos daqueles que devem cuidar delas. No entanto, quantas destas crianças recebem ajuda, quais os serviços que recebem pela agência que permanece em grande parte desconhecida. Além disso, os países mal-sabíamos quais os maus tratos que se tornam fatais. Trata-se de uma grande lacuna de conhecimento que se deve, provavelmente, a formas inconsistentes de pesquisar e reportar serviços de maus tratos a crianças em toda a Europa. Sem esta informação, não podemos saber como funcionam os sistemas, que esforços preventivos adicionais são necessários, se as intervenções se adequam às necessidades das vítimas ou se os grupos mais vulnerávels estão devidamente Identificados.</span>
          </div>
        </div>
      </div>
    </div>
</section>

 <!------------------------------- Notícias ------------------------------------>

 <section>
    <div class="noticias-container">
        <div class="noticias-header">
          <h1>Últimas Notícias </h1>
          <button onclick="location.href='noticia.php'" >Ver todas</button>
        </div>
      <div class="noticias-area">
        <div onclick="location.href='sersolidario.php'" class="noticias-box">
          <div class="noticias-imagem">
            <img src="assets/Imagens/SERSOLIDARIO.png" alt="UPFAMILIES">
          </div>
          <div class="noticias-titulo">
            <h2>Programa 'Ser Solidário' </h2>
          </div>
          <div class="noticias-antevisao">
            <span>Nos ámbitos do apoio social e do exercício da responsabilidade social, a Universidade da Beira Interior decidiu implementar o programa 'Ser Solidário', com o objetivo de desenvolver mecanismos complementares para uma resposta mals eficaz e abrangente na concessão de apolos socials aos membros da sua comunidade académica.</span>
          </div>
        </div>
        </div>
      </div>
    </div>
</section>
</main>
<script src="./assets/JS/buttonsIndex.js"></script>
<script src="./assets/JS/slider.js"></script>
<?php
   include './app/include/footer.php'
?>
</body>
</html>
