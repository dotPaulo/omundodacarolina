<?php 
    $headerPath = './app/include/header.php';
    $scrollbarPath = './app/include/scrollbar.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/CSS/posts.css">
    <title>SerSolidário | omundodacarolina</title>
    <link rel="shortcut icon" type="image/png" href="assets/Imagens/favicon.ico">
</head>
<body>
<?php include $headerPath; ?>
<?php include $scrollbarPath; ?>
    <main>
        <section>
            <div class="post-container">
                <div class="post-box">
                    <div class="image-container">
                        <img src="assets/Imagens/SERSOLIDARIO.png" alt="casper">
                    </div>
                    <div class="content">
                        <div class="title-container">
                            <h1>Programa 'Ser solidário'</h1>
                        </div>
                        <p>
                            Nos âmbitos do apoio social e do exercício da responsabilidade social, a Universidade da
                            Beira Interior decidiu Implementar o programa 'Ser Solidário', com o objetivo de desenvolver
                            mecanismos complementares para uma resposta mais eficaz e abrangente na concessão de apoios
                            sociais aos membros da sua comunidade académica.
                        </p> <br>
                        <p>
                            O programa visa propiciar um sistema que articule e direcione os contributos de indivíduos e
                            entidades, em valores monetários, bens ou trabalho, para a prevenção ou resolução de
                            problemas sociais concretos.
                        </p> <br>
                        <p>
                            Para o efeito, dispõe de um conjunto de instrumentos - o Fundo Solidário, a Loja Solidária e
                            o Banco de Solidariedade, que visam promover a solidariedade e equidade social, bem como a
                            redução do abandono escolar por razões de cariz económico e social.
                        </p> <br>
                        <div class="title-container">
                            <h2>Deatlhes de ação</h2>
                        </div>
                        <p>
                            O Programa Ser Solidário aderiu ao <a target="_blank"
                                href="http://colaborar.pt/projetos/details/18/16">Ano Nacional da Colaboração</a>
                            iniciativa de âmbito nacional promovida pelo Forum para a Governação Integrada (Forum
                            Govint) e seus promotores. Ao longo de 2019 pretende-se mobilizar e inspirar a sociedade
                            portuguesa, através dos/as cidadãos/as e das instituiçoes para a relevância estratégica da
                            colaboração, quer como forma de resolução de problemas, quer de otimização dos recursos
                            disponíveis.
                        </p> <br>
                        <p>
                            <a target="_blank"
                                href="https://www.ubi.pt/Ficheiros/Entidades/91358/Despacho%20n%C2%BA%202020_R_56-A%20(1).pdf">Despacho
                                n.º 2020/R/56-A</a>
                        </p> <br>
                        <p>
                            <a target="_blank"
                                href="https://www.ubi.pt/Ficheiros/Entidades/91358/Despacho%20N.%C2%BA%202018_R_64.pdf">Despacho
                                de Criação do Programa 'Ser Solidário</a>
                        </p> <br>
                        <p>
                            <a target="_blank"
                                href="https://www.ubi.pt/Ficheiros/Entidades/91358/Despacho%20N.%C2%BA%202020_R_8.pdf">Alteração
                                ao Despacho n° 2018/R/64</a>
                        </p> <br>
                        <p>
                            <a target="_blank"
                                href="https://www.ubi.pt/Ficheiros/Entidades/91358/ApSersolidario.pdf">Apresentação do
                                Programa</a>
                        </p> <br>
                        <p>
                            <a target="_blank"
                                href="https://www.ubi.pt/Ficheiros/Entidades/91358/relatorio%20ser%20solidario%202018_2019_(28_01_20).pdf">Relatório
                                de Atividades 2018 e 2019</a>
                        </p> <br>
                        <ul>
                            <li>Programa aderente ao</li>
                            <img class="ANC" src="assets/Imagens/ANC.png" alt="Ano nacional da colaboração">
                            <li>Mais informações</li> <br>
                        </ul>
                        <p>
                            vrfinanceirahrs@ubi.pt
                        </p> <br>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <?php include './app/include/footer.php'; ?>
</body>

</html>