<?php 
    $headerPath = './app/include/header.php';
    $scrollbarPath = './app/include/scrollbar.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/CSS/posts.css">
    <title>EuroCan | omundodacarolina</title>
    <link rel="shortcut icon" type="image/png" href="assets/Imagens/favicon.ico">
</head>
<body>
<?php include $headerPath; ?>
<?php include $scrollbarPath; ?>
    <main>
        <section>
            <div class="post-container">
                <div class="post-box">
                    <div class="image-container">
                        <img src="assets/Imagens/EuroCan.png" alt="EuroCan">
                    </div>
                    <div class="content">
                        <div class="title-container">
                            <h1>CA19106 - Respostas Multissetoriais ao abuso e negligências</h1>
                        </div>
                        <p>Na Europa, milhões de crianças sofrem abusos ou negligências nas mãos daqueles que devem
                            cuidar delas. No entanto, quantas destas crianças recebem ajuda, quais os serviços que
                            recebem pela agência que permanece em grande parte desconhecida. Além disso, os países
                            mal-sabíamos quais os maus tratos que se tornam fatais. Trata-se de uma grande lacuna de
                            conhecimento que se deve, provavelmente, a formas inconsistentes de pesquisar e reportar
                            serviços de maus tratos a crianças em toda a Europa. Sem esta informação, não podemos saber
                            como funcionam os sistemas, que esforços preventivos adicionais são necessários, se as
                            Intervenções se adequam às necessidades das vítimas ou se os grupos mais vulneráveis estão
                            devidamente identificados. </p> <br>
                        <p>
                            O projeto proposto aborda esta lacuna através da criação de uma rede de peritos em maus
                            tratos a crianças e partes interessadas relevantes e liga-os aos grupos de trabalho, a fim
                            de promover o desenvolvimento de uma metodologia rigorosa, consistente e comparável para a
                            recolha de dados de vigilância sobre maus tratos a crianças e vítimas mortals relacionadas
                            com maus tratos. Investigadores, decisores políticos, administradores e profissionais
                            identificarão métodos de vigilância de boas práticas e recomendarão formas eficientes de os
                            implementar em toda a Europa. É importante que esta rede convide jovens e adultos
                            sobreviventes de maus tratos a crianças a colaborar em todos os processos de tomada de
                            decisão do grupo de trabalho.
                        </p> <br>
                        <p>
                            Os quatro grupos de trabalho desta rede centrar-se-ão em: 1) a definição e operacionalização
                            de maus tratos a crianças; 2) promover análises secundárias; 3) abordagens participativas à
                            vigilância de maus tratos a crianças; e 4) Implementação e divulgação. Os produtos finals
                            destes projetos incluirão orientações para a implementação das melhores práticas em matéria
                            de vigilância de maus tratos a crianças em toda a Europa.
                        </p> <br>
                        <div class="title-container">
                            <h2>Detalhes de ação</h2>
                        </div>
                        <ul>
                            <li>Nov - 09/20</li>
                            <li>Data de aprovação do CSO - 24/03/2020</li>
                            <li>Data de início - 05/10/2020</li>
                            <li>Data de fim - 04/10/2024</li> <br>
                        </ul>
                        <a target="_blank"
                            href="https://liu.se/en/research/barnafrid/euro-can">https://liu.se/en/research/barnafrid/euro-can</a>
                        <div class="title-container">
                            <h2>Como posso participar?</h2>
                        </div>
                        <p>
                            => Leia o Projeto Descrição <a
                                href="https://e-services.cost.eu/files/domain_files/CA/Action_CA19106/mou/CA19106-e.pdf">MoU</a>
                        </p> <br>
                        <p>
                            => Informe o Proponente/Presidente principal do seu interesse (e-mail)
                        </p> <br>
                        <p>
                            => <a target="_blank" href="https://e-services.cost.eu/user/login">Inscreva-se</a> para
                            integrar os seus Grupos de Trabalho de interesse
                        </p> <br>
                        <p>
                            => Por favor, note que as nomeações do Comité de Gestão são realizadas através dos <a
                                target="_blank"
                                href="https://www.cost.eu/about/who-is-who/#tabs+Name:National%20Coordinators">Pontos de
                                Contacto Nacionais COST</a>
                        </p> <br>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <?php include './app/include/footer.php'; ?>
</body>

</html>