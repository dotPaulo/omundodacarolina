<?php

return [
    'jwt_secret' => "iergWfiu3W4oiErpoejqroErRtuihtLIYG%/iwjrfefgr*gdfhyhy37it2i3gkehfbYDGjgsaHGFGDe3"
];

?>